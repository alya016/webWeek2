export const ONLY_PRODUCTS = [
  {
    id: 10,
    name: 'Laptop',
    categoryId: 1,
    description: 'Super Fancy Laptop'
  },
  {
    id: 11,
    name: 'iPad',
    categoryId: 1,
    description: 'Super Fancy iPad'
  },
  {
    id: 12,
    name: 'iPhone',
    categoryId: 1,
    description: 'Super Fancy iPhone'
  },
  {
    id: 20,
    categoryId: 2,
    name: 'Sofa',
    description: 'Cozy sofa'
  },
  {
    id: 30,
    categoryId: 3,
    name: 'Gone with the wind',
    description: 'Скарлетт О\'Хара'
  },
  {
    id: 40,
    categoryId: 4,
    name: 'Zara',
    description: 'T-shirt'
  }
];
