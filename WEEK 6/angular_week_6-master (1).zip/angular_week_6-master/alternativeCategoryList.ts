export const ALTERNATIVE_CATEGORY_LIST = [
  {
    name: 'Электроника',
    id: 1
  },
  {
    name: 'Дом',
    id: 2
  },
  {
    name: 'Книги',
    id: 3
  },
  {
    name: 'Одежда',
    id: 4
  }
];

